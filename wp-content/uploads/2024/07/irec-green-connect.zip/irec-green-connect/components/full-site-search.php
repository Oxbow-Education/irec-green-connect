<form id="full-site-searchbox" action="" class="hidden">
  <input type="text" id="fullSiteSearch" name="search" placeholder="Search for a page or resource">
  <div id="fullSearchHits"></div>
  <p id="no-results-message" style="display: none">No results.
  </p>
</form>