(function ($) {
  'use strict';
})(jQuery);
